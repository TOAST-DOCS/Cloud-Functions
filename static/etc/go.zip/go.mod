module example.com/ncf

require github.com/brianvoe/gofakeit/v6 v6.28.0
